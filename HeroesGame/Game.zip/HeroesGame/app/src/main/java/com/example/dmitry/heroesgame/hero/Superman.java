package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 23.04.2016.
 */
public class Superman extends Hero {

    public Superman(){
        image = new int[]{R.drawable.superman1, R.drawable.superman2, R.drawable.superman3, R.drawable.superman4};
        name = "Супермен";
    }
}
