package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class GreenArrow extends Hero {

    public GreenArrow(){
        image = new int[]{R.drawable.greenstrela1, R.drawable.greenstrela2, R.drawable.greenstrela3, R.drawable.greenstrela4};
        name = "Зелёная стрела";
    }
}
