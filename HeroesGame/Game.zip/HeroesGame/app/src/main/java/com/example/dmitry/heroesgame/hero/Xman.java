package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class Xman extends Hero {

    public Xman(){
        image = new int[]{R.drawable.xman1, R.drawable.xman2, R.drawable.xman3, R.drawable.xman4};
        name = "Профессор Икс";
    }
}
