package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 23.04.2016.
 */
public class Spiderman extends Hero {

    public Spiderman(){
        image = new int[]{R.drawable.spiderman1, R.drawable.spiderman2, R.drawable.spiderman3, R.drawable.spiderman4};
        name = "Человек-паук";
    }
}
