package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class Turtle extends Hero {

    public Turtle(){
        image = new int[]{R.drawable.turtle1, R.drawable.turtle2, R.drawable.turtle3, R.drawable.turtle4};
        name = "Рафаэль";
    }
}
