package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class CatGirl extends Hero {

    public CatGirl(){
        image = new int[]{R.drawable.catgirl1, R.drawable.catgirl2, R.drawable.catgirl3, R.drawable.catgirl4};
        name = "Женщина-кошка";
    }
}
