package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class RickGrayms extends Hero {

    public RickGrayms(){
        image = new int[]{R.drawable.rickgrimes1, R.drawable.rickgrimes2, R.drawable.rickgrimes3, R.drawable.rickgrimes4};
        name = "Рик Граймс";
    }
}
