package com.example.dmitry.heroesgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.dmitry.heroesgame.R;

public class Enter extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);


    }
}
