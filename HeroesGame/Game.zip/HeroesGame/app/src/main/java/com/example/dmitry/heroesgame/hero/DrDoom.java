package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class DrDoom extends Hero {

    public DrDoom(){
        image = new int[]{R.drawable.drdoom1, R.drawable.drdoom2, R.drawable.drdoom3, R.drawable.drdoom4};
        name = "Доктор Дум";
    }
}
