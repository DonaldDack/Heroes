package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class HellBoy extends Hero {

    public HellBoy(){
        image = new int[]{R.drawable.hallboy1, R.drawable.hallboy2, R.drawable.hallboy3, R.drawable.hallboy4};
        name = "Хеллбой";
    }
}
