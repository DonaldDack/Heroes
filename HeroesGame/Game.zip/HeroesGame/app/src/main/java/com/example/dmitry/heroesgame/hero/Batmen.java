package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 23.04.2016.
 */
public class Batmen extends Hero {

    public Batmen(){
        image = new int[]{R.drawable.batmen1, R.drawable.batmen2, R.drawable.batmen3, R.drawable.batmen4};
        name = "Бэтмен";

    }
}
