package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class Joker extends Hero {

    public Joker(){
        image = new int[]{R.drawable.joker1, R.drawable.joker2, R.drawable.joker3, R.drawable.joker4};
        name = "Джокер";
    }
}
