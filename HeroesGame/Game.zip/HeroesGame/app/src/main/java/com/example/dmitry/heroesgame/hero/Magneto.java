package com.example.dmitry.heroesgame.hero;

import com.example.dmitry.heroesgame.Hero;
import com.example.dmitry.heroesgame.R;

/**
 * Created by Dmitry on 24.04.2016.
 */
public class Magneto extends Hero {

    public Magneto(){
        image = new int[]{R.drawable.magneto1,R.drawable.magneto2, R.drawable.magneto3, R.drawable.magneto4};
        name = " \tМагнето";
    }
}
